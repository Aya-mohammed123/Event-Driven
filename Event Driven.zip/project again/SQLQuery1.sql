﻿select * from HomeDevice;

