﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    internal class customer
    {

        private string _name;
        private string _phoneNo;
        private string _address;
        private string _email;
        private string _nationality;
        public customer()
        {
            _name = "";
            _phoneNo = "";
            _address = "";
            _email = "";
            _nationality = "";
        }


        public customer(string n, string ph, string add, string em, string nation)
        {
            _name = n;
            _phoneNo = ph;
            _address = add;
            _email = em;
            _nationality = nation;
        }
        public void SetName(string n)
        {
            _name = n;
        }
        public void SetAdd(string add)
        {
            _address = add;
        }
        public void SetEmail(string em)
        {
            _email = em;
        }
        public void SeNationality(string nation)
        {
            _nationality = nation;
        }           
        public void SetNo(string ph,Form9 frm9)
        {
            int p;
            if(int.TryParse(_phoneNo,out p))
            {
                _phoneNo = ph;
            }
            else
            {
                MessageBox.Show("Invalid phone no");
                frm9.textBox2.Clear();
            }
        }
        public string GetName()
        {
            return _name;
        }
        public string GetNo()
        {
            return _phoneNo;
        }
        public string GetAddress()
        {
            return _address;
        }
        public string GetEmail()
        {
            return _email;
        }
        public string GetNationality()
        {
            return _nationality;
        }
          
    }
}
