﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_again
{
    internal class Maneger
    {
        public void PassWord(string password, Form3 frm3)
        {
            if (password != "123pwd")
            {
                MessageBox.Show("Wrong Password please try again ");
                //frm3.textBox1.Text = "";
                frm3.textBox1.Clear();
            }
            else
            {
                Form4 frm4 = new Form4();
                frm4.Show();
                frm3.Hide();
            }
        }
    }
}
