﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void accessoriesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.accessoriesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.Accessories' table. You can move, or remove it, as needed.
            this.accessoriesTableAdapter.Fill(this.test_dataSet1.Accessories);

        }
        //Back
        private void button1_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }
        //return to main form 
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void accessoriesDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {//Accessories
            
            //e.RowIndex ......e is an object from DataGridViewCellEventArgs
            //RowIndex.......row that admin select
            //calls[name of coulmn] or can be no of coulmn start from 0 as index
            idTextBox.Text = accessoriesDataGridView.CurrentRow.Cells[0].Value.ToString();

            priceTextBox.Text = accessoriesDataGridView.CurrentRow.Cells[3].Value.ToString();
        }
        //ubdate
        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "UPDATE Accessories  SET Price=@Price WHERE Id=" +
                accessoriesDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            //Higlight parameter you want to ubdate 
            cmd.Parameters.AddWithValue("@Price", priceTextBox.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Ubdated successfully");
            //  load to review table  
            this.accessoriesTableAdapter.Fill(this.test_dataSet1.Accessories);
        }
        //Review table
        private void button6_Click(object sender, EventArgs e)
        {
            this.accessoriesTableAdapter.Fill(this.test_dataSet1.Accessories);
        }
        //Delete items
        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "DELETE FROM Accessories  WHERE Id=" +
                accessoriesDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("deleted successfully");
            //  load to review table  
            this.accessoriesTableAdapter.Fill(this.test_dataSet1.Accessories); 
        }
        //search by code
        private void button3_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Accessories]WHERE DeviceName LIKE '%" + textBox1.Text + "%'", con); //queuri
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            accessoriesDataGridView.DataSource = dt;
            con.Close();
        }
    }
}
