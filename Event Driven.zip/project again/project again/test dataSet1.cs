﻿namespace project_again
{


    partial class test_dataSet1
    {
        partial class LaptopDataTable
        {
        }
    }
}

namespace project_again.test_dataSet1TableAdapters
{
    partial class AccessoriesTableAdapter
    {
    }

    partial class LaptopTableAdapter
    {
    }

    public partial class Home_deviceTableAdapter {
    }
}
