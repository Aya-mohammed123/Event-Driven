﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace project_again
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
             


        }
        //Selsect price of prouduct when user select product name 
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < listBox2.Items.Count)
            {
                listBox2.SetSelected(selectedIndex, true);
            }
           // MessageBox.Show(selectedIndex.ToString());
        }
        private void button1_Click(object sender, EventArgs e)
        { 
            if(radioButton1.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT DeviceName  FROM HomeDevice";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                      listBox1.BeginUpdate();
                    listBox1.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox1.Items.Add(rdr["DeviceName"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox1.EndUpdate(); 

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton2.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT DeviceBrand  FROM Phone";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                      listBox1.BeginUpdate();
                    listBox1.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox1.Items.Add(rdr["DeviceBrand"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox1.EndUpdate(); 

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton3.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT DeviceBrand  FROM Laptop";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox1.BeginUpdate();
                    listBox1.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox1.Items.Add(rdr["DeviceBrand"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox1.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton4.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT DeviceName  FROM Accessories";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox1.BeginUpdate();
                    listBox1.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox1.Items.Add(rdr["DeviceName"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox1.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("can you selsct what you want");
            }
            if (radioButton1.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT Price  FROM HomeDevice";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox2.BeginUpdate();
                    listBox2.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox2.Items.Add(rdr["Price"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox2.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton2.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT Price  FROM Phone";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox2.BeginUpdate();
                    listBox2.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox2.Items.Add(rdr["Price"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox2.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton3.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT Price  FROM Laptop";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox2.BeginUpdate();
                    listBox2.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox2.Items.Add(rdr["Price"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox2.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (radioButton4.Checked)
            {
                SqlConnection dbConn = new SqlConnection();
                try
                {
                    dbConn.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
                    string sqlStr = @"SELECT Price  FROM Accessories";
                    SqlCommand cmd = new SqlCommand(sqlStr, dbConn);
                    dbConn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    listBox2.BeginUpdate();
                    listBox2.Items.Clear();
                    while (rdr.Read())
                    {
                        listBox2.Items.Add(rdr["Price"].ToString());
                    }
                    rdr.Close();
                    dbConn.Close();
                    listBox2.EndUpdate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        //quantaty +
        private void button2_Click(object sender, EventArgs e)
        {
            int x = int.Parse(label2.Text);
            x = x + 1;
            label2.Text = x.ToString();
        }

        //quantaty +
        private void button3_Click_1(object sender, EventArgs e)
        {
            
            int x = int.Parse(label2.Text);
            if(x>1)
            {
                x = x - 1;
                label2.Text = x.ToString();
            }
            
        }
        //show price
        private void button4_Click(object sender, EventArgs e)
        {
            string selectedItemText = listBox2.SelectedItem.ToString();
            //MessageBox.Show(selectedItemText);
            
            int x=int.Parse(selectedItemText);//price
            int y = int.Parse(label2.Text);//quantaty
            int price = x * y;
            textBox1.Text = price.ToString();
            
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //Back
        private void button5_Click(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.Show();
            this.Hide();
        }
        //buy anther one
        private void button6_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            listBox1.ClearSelected();
            listBox2.ClearSelected();
            label2.Text = "1";
            /*
             int x = 0;
            int y = int.Parse(textBox1.Text);
            x += y;
            */
            textBox1.Text = " ";
            button1.PerformClick();
            button2.PerformClick();
            button3.PerformClick();
            //button4.PerformClick();

        }
        //Next
        private void button7_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }
    }
} 
