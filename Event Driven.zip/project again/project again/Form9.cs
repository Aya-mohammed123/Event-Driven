﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data.SqlClient;



namespace project_again
{
    public partial class Form9 : Form
    {
        /*
         * Data source=server name
         * intial catalog=Database name
         * integrated security
         * static because connection will never change
         */
        public Form9()
        {
            InitializeComponent();
        }
        //Back
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
        //insert to database and next 
        private void button2_Click(object sender, EventArgs e)
        { 
            customer x = new customer(textBox1.Text, textBox2.Text, textBox3.Text,
               textBox4.Text, comboBox1.Text);
            bool done = false;

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" ||
             textBox4.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Please,Enter all data");
            }     
            else
            {
                //tryparse exception
                x.SetNo(textBox2.Text, this);

                try
                {
                    string email = x.GetEmail();
                    //find @ positon
                    string protocol = "@gmail.com";
                    int start = email.IndexOf('@');
                    //Get location of email protocol
                    string last = email.Substring(start);
                    if (last == protocol)
                    {
                        done = true;
                    }
                    else
                    {
                        throw new ArgumentOutOfRangeException(nameof(email), "must have@gmail.com ");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("must have@gmail.com ");
                    textBox4.Text = "";
                }
            }
            //insert new row in database
            string query = "INSERT INTO PersonInfo(Name , PhoneNo , Address , Email , City ) " +
                "VALUES (@Name , @PhoneNo , @Address , @Email , @City)";
              SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);

            //Higlight parameter you want to Add
            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
            cmd.Parameters.AddWithValue("@PhoneNo", textBox2.Text);
            cmd.Parameters.AddWithValue("@Address", textBox3.Text);
            cmd.Parameters.AddWithValue("@Email", textBox4.Text);
            cmd.Parameters.AddWithValue("@City", comboBox1.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            //next form
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" &&
           textBox4.Text != "" && comboBox1.Text != "" && done == true)
            {
                Form10 frm10 = new Form10();
                frm10.Show();
                this.Hide();
            }
            
             

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.PersonInfo' table. You can move, or remove it, as needed.
            //this.personInfoTableAdapter.Fill(this.test_dataSet1.PersonInfo);
            //load user table 


        }
        /*
        public DataTable loadUserTable()
        {
            DataTable dt = new DataTable();
            string query = "SELECT *FROM PersonInfo";
             SqlConnection con = new SqlConnection();
             con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }
        */
        private void personInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }
    }      
            
              
               
             
            

}
        /*
        private void person_infoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
          //  this.person_infoBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.Person_info' table. You can move, or remove it, as needed.
           //this.person_infoTableAdapter.Fill(this.test_dataSet1.Person_info);
             
             //fill combo box from data base
             
            //comboBox1.DataSource = "select cityname from city";
            //comboBox1.DisplayMember = "cityname";
            //comboBox1.ValueMember = "id";
            
        }
          */
