﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void laptopBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.laptopBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.Laptop' table. You can move, or remove it, as needed.
            this.laptopTableAdapter.Fill(this.test_dataSet1.Laptop);

        }
        public DataTable loadUserTable()
        {
            DataTable dt = new DataTable();
            string query = "SELECT *FROM PersonInfo";
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }
        //Back button
        private void button4_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }
        //Return to main form
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void laptopDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            //e.RowIndex ......e is an object from DataGridViewCellEventArgs
            //RowIndex.......row that admin select
            //calls[name of coulmn] or can be no of coulmn start from 0 as index
            idTextBox.Text = laptopDataGridView.CurrentRow.Cells[0].Value.ToString();

            priceTextBox.Text = laptopDataGridView.CurrentRow.Cells[5].Value.ToString();

            quantaty_TextBox.Text = laptopDataGridView.CurrentRow.Cells[6].Value.ToString();
            
        }

        private void quantaty_TextBox_TextChanged(object sender, EventArgs e)
        {

        }
        //Ubdate 
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "UPDATE Laptop  SET Quantaty=@Quantaty , Price=@Price WHERE Id=" +
                laptopDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            //Higlight parameter you want to ubdate 
            cmd.Parameters.AddWithValue("@Quantaty", quantaty_TextBox.Text);
            cmd.Parameters.AddWithValue("@Price", priceTextBox.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Ubdated successfully");
            //  load to review table  
            this.laptopTableAdapter.Fill(this.test_dataSet1.Laptop);
        }
        //search
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Laptop]WHERE DeviceBrand LIKE '%" + textBox1.Text + "%'", con); //queuri
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            laptopDataGridView.DataSource = dt;
            con.Close();
            //using filter
            //this.laptopTableAdapter.DeviceName(this.test_dataSet1.Laptop,textBox1.Text);
        }
        //Delete item 
        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "DELETE FROM Laptop  WHERE Id=" +
                laptopDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("deleted successfully");
            //  load to review table  
            this.laptopTableAdapter.Fill(this.test_dataSet1.Laptop);
        } 
         
    }
}
