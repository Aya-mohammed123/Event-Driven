﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.Accessories' table. You can move, or remove it, as needed.
            //this.accessoriesTableAdapter.Fill(this.test_dataSet1.Accessories);

        }

        private void accessoriesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.accessoriesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //admin
            if (radioButton1.Checked)
            {
                Form3 frm3 = new Form3();
                frm3.Show();
                this.Hide();
            }
            //customer
            else if (radioButton2.Checked)
            { 
                Form9 frm9 = new Form9();
                frm9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Select one item "); 
            }
        }
    }
}
