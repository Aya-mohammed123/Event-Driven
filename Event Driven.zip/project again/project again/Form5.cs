﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void homeDeviceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.homeDeviceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void Form5_Load(object sender, EventArgs e)
        { 
            // TODO: This line of code loads data into the 'test_dataSet1.HomeDevice' table. You can move, or remove it, as needed.
            this.homeDeviceTableAdapter.Fill(this.test_dataSet1.HomeDevice);

        }
        private void homeDeviceDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            //e.RowIndex ......e is an object from DataGridViewCellEventArgs
            //RowIndex.......row that admin select
            //calls["name of coulmn"] or can be no of coulmn start from 0 as index
            idTextBox.Text = homeDeviceDataGridView.CurrentRow.Cells[0].Value.ToString();

            quantany_TextBox.Text = homeDeviceDataGridView.CurrentRow.Cells[3].Value.ToString();

            price_TextBox.Text = homeDeviceDataGridView.CurrentRow.Cells[6].Value.ToString();

        }
        //Search
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [HomeDevice]WHERE DeviceName LIKE '%" + textBox1.Text + "%'", con); //queuri
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            homeDeviceDataGridView.DataSource = dt;
            con.Close();

            //using filter

            //this.homeDeviceTableAdapter.FillBy(this.test_dataSet1.HomeDevice,textBox1.Text);
        }
        //Back
        private void button2_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }
        private void homeDeviceDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
         
         

        //UPDATE selected ITEM from database
        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "UPDATE HomeDevice  SET Quantany=@Quantany , Price=@Price WHERE Id=" +
                homeDeviceDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            //Higlight parameter you want to ubdate 
            cmd.Parameters.AddWithValue("@Quantany", quantany_TextBox.Text);
            cmd.Parameters.AddWithValue("@Price", price_TextBox.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Ubdated successfully");
            //  load to review table  

            this.homeDeviceTableAdapter.Fill(this.test_dataSet1.HomeDevice);
        }



        //Delete selected ITEM from database
        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "DELETE FROM  HomeDevice  WHERE Id=" +
                homeDeviceDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("deleted successfully");
            //  load to review table  
            this.homeDeviceTableAdapter.Fill(this.test_dataSet1.HomeDevice);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
    }
}
