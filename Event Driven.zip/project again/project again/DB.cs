﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections;

namespace project_again
{
    internal class DB
    {
        string connectionstring = "Data Source=.\\SQLEXPRESS;Initial Catalog=MyDB;Integrated Security=True";
        SqlConnection con =null;
        public DB()
        {
            con = new SqlConnection(connectionstring);
        }
        public void Excute(string Query)
        {
           
            try
            {
                
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
                
            
        }
        public SqlDataReader Select(string Query)
        { 
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }
    }
}
