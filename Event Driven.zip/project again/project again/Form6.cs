﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_again
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void phoneBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.phoneBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.test_dataSet1);

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'test_dataSet1.Phone' table. You can move, or remove it, as needed.
            this.phoneTableAdapter.Fill(this.test_dataSet1.Phone);

        }

        private void phoneDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //e.RowIndex ......e is an object from DataGridViewCellEventArgs
            //RowIndex.......row that admin select
            //calls[name of coulmn] or can be no of coulmn start from 0 as index
            idTextBox.Text = phoneDataGridView.CurrentRow.Cells[0].Value.ToString();

            priceTextBox.Text = phoneDataGridView.CurrentRow.Cells[5].Value.ToString();

            quantatyTextBox.Text = phoneDataGridView.CurrentRow.Cells[6].Value.ToString();
            
        }
        //Back button 
        private void button3_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }
        //Next button ....return to main form
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
        //Ubdate selected ITEM from database
        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "UPDATE Phone  SET Quantaty=@Quantaty , Price=@Price WHERE Id=" +
                phoneDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            //Higlight parameter you want to ubdate 
            cmd.Parameters.AddWithValue("@Quantaty", quantatyTextBox.Text);
            cmd.Parameters.AddWithValue("@Price", priceTextBox.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Ubdated successfully");
            //  load to review table  
            this.phoneTableAdapter.Fill(this.test_dataSet1.Phone);
        }
        //search
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Phone]WHERE DeviceBrand LIKE '%" + textBox1.Text + "%'", con); //queuri
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            phoneDataGridView.DataSource = dt;
            con.Close();



            // this.phoneTableAdapter.searchPhone(this.test_dataSet1.Phone,textBox1.Text);
        }
        //Delete selected ITEM from database
        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ("server=DESKTOP-GAOJG5B\\SQLEXPRESS;database=master;integrated security =true");
            con.Open();
            string query = "DELETE FROM  Phone  WHERE Id=" +
                phoneDataGridView.CurrentRow.Cells[0].Value.ToString();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("deleted successfully");
            //  load to review table  
            this.phoneTableAdapter.Fill(this.test_dataSet1.Phone);
        }
         
    }
}
